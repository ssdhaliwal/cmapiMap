import React, { Component } from 'react';
import './App.css';

const headerStyle = {
  height: "200px",
  width: "100%",
  position: "absolute",
  top: 0,
  backgroundColor: "lightblue",
  minHeight: "unset"
};

const latlonStyle = {
  color: "black"
}

const frameStyle = {
  overflow: "hidden",
  height: "50%",
  width: "50%",
  position: "absolute",
  bottom: 0,
  right: 0,
  backgroundColor: "azure"
};

const iframeStyle = {
  width: "100%",
  height: "100%",
  display: "block"
}

class App extends Component {
  constructor() {
    super();

    this.state = {
      "mapClick": {
        "payload": {
          "lat": 0,
          "lon": 0
        }
      }
    };
  }

  componentDidMount() {
    const self = this;

    window.receiveMessageFromIndex = function (event) {
      if (event !== undefined) {
        console.log('IFrame> ', event.data);

        let clickData;
        try {
          clickData = JSON.parse(event.data);
          clickData.payload = JSON.parse(clickData.payload);

        } catch (error) { console.log("JSON parse error/" + error + "\n" + event.data) };

        if (clickData.channel === "map.view.clicked") {
          self.setState({ mapClick: clickData });
          self.sendMessageCenterOnClickToMap(self.state);
        }
      }
    }

    window.addEventListener("message", window.receiveMessageFromIndex, false);
  }

  sendMessagePlotUrlToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test Url-51FS",
      "url": "https://sampleserver3.arcgisonline.com/ArcGIS/rest/services/Petroleum/KSPetro/MapServer/1/",
      "params": {
        "serviceType": "feature",
        "definitionExpression": "PROD_GAS='" + state + "'"
      }
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.plot.url", "payload": message }), '*');
  };

  sendMessageRemoveToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test Url-51FS"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.remove", "payload": message }), '*');
  };

  sendMessageShowToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test Url-51FS"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.show", "payload": message }), '*');
  };

  sendMessageHideToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test Url-51FS"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.hide", "payload": message }), '*');
  };

  sendMessageCenterToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "location": {
        "lat": 42.39437,
        "lon": -71.02821
      }, 
      "zoom": 8
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.view.center.location", "payload": message }), '*');
  };

  sendMessageCenterOnClickToMap(state) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "location": {
        "lat": this.state.mapClick.payload.lat,
        "lon": this.state.mapClick.payload.lon
      }, 
      "zoom": 8, 
      "hideAfter": 5000
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.view.center.location", "payload": message }), '*');
  };

  render() {
    return (
      <div className="App">
        <div className="App-header" style={headerStyle}>
          <p>This app communicates with iframe and runs on port 3000</p>
          <button onClick={() => this.sendMessageCenterToMap("Yes")}>CENTER ON LOCATION</button>
          <button onClick={() => this.sendMessagePlotUrlToMap("Yes")}>PLOT w/SEARCH</button>
          <button onClick={() => this.sendMessageShowToMap("Yes")}>PLOT SHOW</button>
          <button onClick={() => this.sendMessageHideToMap("Yes")}>PLOT HIDE</button>
          <button onClick={() => this.sendMessageRemoveToMap("Yes")}>PLOT REMOVE</button>
          <button onClick={() => this.sendMessageCenterOnClickToMap("Yes")}>MAP CENTER ON CLICK</button>
          <div style={latlonStyle}>
            LAT: {this.state.mapClick.payload.lat} // LON: {this.state.mapClick.payload.lon}
          </div>
        </div>
        <div style={frameStyle}>
          <iframe src="https://localhost:8443/esri-cmapi/index.html" id="cmapiMap" title="CMAPI MAP" scrolling="auto"
            allowtransparency="false" style={iframeStyle}></iframe>
        </div>
      </div>
    );
  }
}

export default App;
