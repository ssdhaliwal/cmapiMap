import React, { Component } from 'react';
import './App.css';

const headerStyle = {
  height: "200px",
  width: "100%",
  position: "absolute",
  top: 0,
  backgroundColor: "lightblue",
  minHeight: "unset"
};

const latlonStyle = {
  color: "black"
}

const frameStyle = {
  overflow: "hidden",
  height: "50%",
  width: "50%",
  position: "absolute",
  bottom: 0,
  right: 0,
  backgroundColor: "azure"
};

const iframeStyle = {
  width: "100%",
  height: "100%",
  display: "block"
}

const buttonSpanStyle = {
  lineHeight: "12px"
}

class App extends Component {
  constructor() {
    super();

    this.state = {
      "mapReady": false,
      "mapClick": {
        "payload": {
          "lat": 0,
          "lon": 0
        }
      }
    };
  };

  componentDidMount() {
    const self = this;

    window.receiveMessageFromIndex = function (event) {
      if (event !== undefined) {
        console.log('IFrame> ', event.data);

        let mapData;
        try {
          mapData = JSON.parse(event.data);
          mapData.payload = JSON.parse(mapData.payload);
        } catch (error) { console.log("JSON parse error/" + error + "\n" + event.data) };

        switch (mapData.channel) {
          case "map.status.initialization":
            if (mapData.payload.status === "ready") {
              console.log("received map.status.initialization/ready; enabling buttons...");

              self.setState({ mapReady: true });
            }
            break;

          case "map.view.clicked":
            console.log("received map.view.clicked; sending click to map to show icon...");

            self.setState({ mapClick: mapData });
            self.sendMessageCenterOnClickToMap(self.state);
            break;
        }
      }
    }

    window.addEventListener("message", window.receiveMessageFromIndex, false);
  };

  sendMessagePlotUrlToMap(condition) {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test SAIS-COSCO",
      "url": "https://cg1v.osc.uscg.mil/server/rest/services/Vessels/Vessels/MapServer/2/",
      "params": {
        "serviceType": "feature",
        "definitionExpression": "VesselName like '" + condition + "%'",
        "showLabels": "true"
      }
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.plot.url", "payload": message }), '*');
  };

  sendMessageRemoveToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test SAIS-COSCO"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.unplot", "payload": message }), '*');
  };

  sendMessageShowToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test SAIS-COSCO"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.show", "payload": message }), '*');
  };

  sendMessageHideToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TEST-01",
      "featureId": "Test SAIS-COSCO"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.hide", "payload": message }), '*');
  };

  sendMessageCenterToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "location": {
        "lat": 42.39437,
        "lon": -71.02821
      }, 
      "zoom": 8
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.view.center.location", "payload": message }), '*');
  };

  sendMessageShowTracksToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TRACKS1001",
      "featureId": "TRACKS1001-01"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.show", "payload": message }), '*');
  };

  sendMessageHideTracksToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "overlayId": "TRACKS1001",
      "featureId": "TRACKS1001-01"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.feature.hide", "payload": message }), '*');
  };

  sendMessageCenterOnClickToMap() {
    const childFrameObj = document.getElementById('cmapiMap');

    let message = {
      "location": {
        "lat": this.state.mapClick.payload.lat,
        "lon": this.state.mapClick.payload.lon
      }, 
      "zoom": 8, 
      "hideAfter": "infinite"
    };

    childFrameObj.contentWindow.postMessage(JSON.stringify({ "channel": "map.view.center.location", "payload": message }), '*');
  };

  render() {
    return (
      <div className="App">
        <div className="App-header" style={headerStyle}>
          <p>This app communicates with iframe and runs on port 3000</p>
          <span style={buttonSpanStyle}>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageCenterToMap()}>CENTER ON LOCATION</button>
            <br/>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessagePlotUrlToMap("COSCO")}>PLOT w/SEARCH</button>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageShowToMap()}>PLOT SHOW</button>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageHideToMap()}>PLOT HIDE</button>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageRemoveToMap()}>PLOT REMOVE</button>
            <br/>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageShowTracksToMap()}>SHOW TRACKS</button>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageHideTracksToMap()}>HIDE TRACKS</button>
            <br/>
            <button disabled={!this.state.mapReady} onClick={() => this.sendMessageCenterOnClickToMap()}>MAP CENTER ON CLICK</button>
          </span>
          <div style={latlonStyle}>
            LAT: {this.state.mapClick.payload.lat} // LON: {this.state.mapClick.payload.lon}
          </div>
        </div>
        <div style={frameStyle}>
          <iframe src="/esri-cmapi/index.html" id="cmapiMap" title="CMAPI MAP" scrolling="auto"
            allowtransparency="false" style={iframeStyle}></iframe>
        </div>
      </div>
    );
  };
}

export default App;
